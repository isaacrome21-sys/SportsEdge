#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, os, sys, traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Tuple

BASE_DIR = Path(__file__).resolve().parent
ENGINE_FILE = BASE_DIR / 'sportsedge_beta_v1_4.py'
REGISTRY_FILE = BASE_DIR / 'SportsEdge_Validation_Registry_v1_4.json'
MANIFEST_FILE = BASE_DIR / 'SportsEdge_Live_Input_Manifest_v1.json'

# Import engine only after config preflight can be inspected independently.
import importlib.util

def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot load module {path}')
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


def load_json(path: Path) -> Dict[str, Any]:
    with path.open('r', encoding='utf-8') as f:
        return json.load(f)


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def parse_ts(x: Any) -> datetime | None:
    if x in (None, '', 'TBD', 'UNKNOWN'):
        return None
    if isinstance(x, datetime):
        return x if x.tzinfo else x.replace(tzinfo=timezone.utc)
    s = str(x).replace('Z', '+00:00')
    try:
        d = datetime.fromisoformat(s)
        return d if d.tzinfo else d.replace(tzinfo=timezone.utc)
    except Exception:
        return None


def age_seconds(ts: Any, now: datetime) -> float | None:
    d = parse_ts(ts)
    if d is None:
        return None
    return max(0.0, (now - d.astimezone(timezone.utc)).total_seconds())


def source_state(snapshot: Dict[str,Any], source: str, manifest: Dict[str,Any], now: datetime) -> Dict[str,Any]:
    rec = (snapshot.get('sources') or {}).get(source) or {}
    max_age = (manifest.get('source_freshness_seconds') or {}).get(source)
    age = age_seconds(rec.get('as_of'), now)
    present = bool(rec.get('available', False))
    if not present:
        status = 'MISSING'
    elif age is None:
        status = 'UNKNOWN_FRESHNESS'
    elif max_age is not None and age > float(max_age):
        status = 'STALE'
    else:
        status = 'PASS'
    return {
        'source': source,
        'status': status,
        'available': present,
        'as_of': rec.get('as_of'),
        'age_seconds': age,
        'max_age_seconds': max_age,
        'provider': rec.get('provider'),
        'detail': rec.get('detail')
    }


def deep_has(obj: Dict[str,Any], dotted: str) -> bool:
    cur: Any = obj
    for part in dotted.split('.'):
        if isinstance(cur, dict) and part in cur and cur[part] not in (None, '', [], {}):
            cur = cur[part]
        else:
            return False
    return True


def canonical_market(engine, market: str) -> str:
    return engine.canonical_market_name(market)


def market_requirements(manifest: Dict[str,Any], market: str) -> Dict[str,Any]:
    markets = manifest.get('markets') or {}
    return markets.get(market, {'sources': [], 'config_fields': []})


def audit_market_inputs(engine, snapshot: Dict[str,Any], manifest: Dict[str,Any], market: str,
                        source_states: Dict[str,Dict[str,Any]]) -> Dict[str,Any]:
    req = market_requirements(manifest, market)
    missing_sources, stale_sources, unknown_sources = [], [], []
    for s in req.get('sources', []):
        st = source_states.get(s, {'status':'MISSING'})['status']
        if st == 'MISSING': missing_sources.append(s)
        elif st == 'STALE': stale_sources.append(s)
        elif st == 'UNKNOWN_FRESHNESS': unknown_sources.append(s)
    missing_fields = [f for f in req.get('config_fields', []) if not deep_has(snapshot, f)]
    reg = engine.validation_record(market)
    eligible = bool(reg.get('official_eligible', False))
    # Preserve diagnostic state and remediation separately. A stale DK price is
    # not the same thing as a missing price, even though both require a fresh screenshot.
    issues = []
    if missing_sources: issues.append({'type':'MISSING_SOURCE','sources':list(missing_sources)})
    if stale_sources: issues.append({'type':'STALE_SOURCE','sources':list(stale_sources)})
    if unknown_sources: issues.append({'type':'UNKNOWN_FRESHNESS','sources':list(unknown_sources)})
    if missing_fields: issues.append({'type':'MISSING_CONFIG_FIELD','fields':list(missing_fields)})

    screenshot_needed = eligible and ('dk_prices' in missing_sources or 'dk_prices' in stale_sources or 'dk_prices' in unknown_sources)
    remediation = []
    if screenshot_needed:
        remediation.append({
            'action':'SCREENSHOT_REQUIRED',
            'label': req.get('screenshot_label') or market,
            'reason': ('missing DK price' if 'dk_prices' in missing_sources
                       else 'stale DK price' if 'dk_prices' in stale_sources
                       else 'DK price freshness unknown')
        })

    if not eligible:
        status = 'BLOCKED'
        reason = reg.get('reason', 'validation registry block')
    elif 'dk_prices' in missing_sources:
        status = 'MISSING_PRICE'
        reason = 'missing source: dk_prices'
    elif 'dk_prices' in stale_sources:
        status = 'STALE_PRICE'
        reason = 'stale source: dk_prices'
    elif 'dk_prices' in unknown_sources:
        status = 'UNKNOWN_PRICE_FRESHNESS'
        reason = 'unknown freshness: dk_prices'
    elif missing_sources:
        status = 'BLOCKED'
        reason = 'missing sources: ' + ', '.join(missing_sources)
    elif stale_sources:
        status = 'STALE'
        reason = 'stale sources: ' + ', '.join(stale_sources)
    elif unknown_sources:
        status = 'UNKNOWN_FRESHNESS'
        reason = 'unknown freshness: ' + ', '.join(unknown_sources)
    elif missing_fields:
        status = 'BLOCKED'
        reason = 'missing live-parity fields: ' + ', '.join(missing_fields)
    else:
        status = 'PASS'
        reason = 'all required live inputs present and fresh'
    return {
        'market': market,
        'status': status,
        'reason': reason,
        'validation_status': reg.get('status','UNVALIDATED'),
        'official_eligible': eligible,
        'missing_sources': missing_sources,
        'stale_sources': stale_sources,
        'unknown_freshness_sources': unknown_sources,
        'missing_config_fields': missing_fields,
        'screenshot_label': req.get('screenshot_label') if screenshot_needed else None,
        'issues': issues,
        'remediation': remediation,
    }


def build_filtered_cfg(engine, snapshot: Dict[str,Any], market_audit: Dict[str,Dict[str,Any]]) -> Tuple[Dict[str,Any], List[Dict[str,Any]]]:
    cfg = json.loads(json.dumps(snapshot.get('model_config') or {}))
    rows = snapshot.get('markets') or cfg.get('markets') or []
    kept, omitted = [], []
    for r in rows:
        m = canonical_market(engine, r.get('market',''))
        a = market_audit.get(m, {'status':'BLOCKED','reason':'market absent from audit'})
        if a['status'] == 'PASS':
            rr = dict(r)
            rr.setdefault('starter_status', snapshot.get('game_state',{}).get('starter_status','CONFIRMED'))
            rr.setdefault('lineup_status', snapshot.get('game_state',{}).get('lineup_status','CONFIRMED'))
            rr.setdefault('weather_status', snapshot.get('game_state',{}).get('weather_status','OK'))
            rr.setdefault('freshness', 'FRESH')
            kept.append(rr)
        else:
            omitted.append({'market':m,'selection':r.get('selection'),'line':r.get('line'),'reason':a['reason'],'status':a['status']})
    cfg['markets'] = kept
    return cfg, omitted


def run_snapshot(snapshot: Dict[str,Any], base_dir: Path=BASE_DIR) -> Dict[str,Any]:
    engine = load_module(base_dir/'sportsedge_beta_v1_4.py', 'sportsedge_beta_v1_4_runtime')
    manifest = load_json(base_dir/'SportsEdge_Live_Input_Manifest_v1.json')
    now = utc_now()
    source_names = sorted(set(manifest.get('source_freshness_seconds',{})) | set((snapshot.get('sources') or {}).keys()))
    source_states = {s: source_state(snapshot,s,manifest,now) for s in source_names}

    required_families = snapshot.get('required_market_families') or manifest.get('required_market_families') or []
    market_audit = {m: audit_market_inputs(engine,snapshot,manifest,m,source_states) for m in required_families}

    cfg, omitted = build_filtered_cfg(engine,snapshot,market_audit)
    result = None
    engine_error = None
    try:
        result = engine.run(cfg) if cfg.get('markets') else {'outputs':[], 'signals':[], 'audit':{}}
    except Exception as e:
        engine_error = f'{type(e).__name__}: {e}'
        result = {'outputs':[], 'signals':[], 'audit':{}, 'traceback': traceback.format_exc(limit=4)}

    outputs = result.get('outputs',[]) if isinstance(result,dict) else []
    # Display floor requested by user: 70+. Official flag remains engine-controlled.
    signals = [x for x in outputs if float(x.get('grade_score',x.get('score',0)) or 0) >= 70.0 and x.get('decision') not in ('PASS','BLOCKED')]
    if not signals and isinstance(result,dict):
        # v1.4 may already expose signals under its own schema.
        signals = [x for x in result.get('signals',[]) if float(x.get('grade_score',x.get('score',70)) or 0) >= 70.0]

    screenshot_requests = []
    for m,a in market_audit.items():
        for rem in a.get('remediation', []):
            if rem.get('action') == 'SCREENSHOT_REQUIRED':
                label = rem.get('label') or a.get('screenshot_label') or m
                if label not in screenshot_requests:
                    screenshot_requests.append(label)

    # Never silently omit a required family.
    family_status = []
    for m in required_families:
        a = market_audit[m]
        family_status.append(a)

    overall = 'PASS'
    if engine_error: overall = 'ENGINE_ERROR'
    elif screenshot_requests: overall = 'PASS_WITH_SCREENSHOT_FALLBACK'
    elif any(a['status'] in ('BLOCKED','STALE','UNKNOWN_FRESHNESS','MISSING_PRICE','STALE_PRICE','UNKNOWN_PRICE_FRESHNESS') for a in family_status): overall = 'PASS_WITH_BLOCKED_MARKETS'

    return {
        'run_meta': {
            'runner_version':'1.1',
            'run_at_utc': now.isoformat(),
            'game_id': snapshot.get('game_id'),
            'game_time': snapshot.get('game_time'),
            'overall_status': overall,
            'engine_error': engine_error,
        },
        'source_audit': list(source_states.values()),
        'market_audit': family_status,
        'omitted_rows': omitted,
        'screenshot_requests': screenshot_requests,
        'MODEL_OUTPUTS': outputs,
        'BET_SIGNALS': signals,
        'ENGINE_AUDIT': result.get('audit',{}) if isinstance(result,dict) else {},
    }


def main():
    ap=argparse.ArgumentParser(description='SportsEdge one-keyword automation/audit wrapper')
    ap.add_argument('snapshot', help='Live snapshot JSON')
    ap.add_argument('--outdir', default='sportsedge_run_output')
    args=ap.parse_args()
    snap=load_json(Path(args.snapshot))
    out=run_snapshot(snap)
    od=Path(args.outdir); od.mkdir(parents=True,exist_ok=True)
    for name,key in [('MODEL_OUTPUTS.json','MODEL_OUTPUTS'),('BET_SIGNALS.json','BET_SIGNALS'),('SYSTEM_AUDIT.json',None)]:
        payload = out if key is None else out[key]
        (od/name).write_text(json.dumps(payload,indent=2,default=str),encoding='utf-8')
    print(json.dumps({'overall_status':out['run_meta']['overall_status'],'signals':len(out['BET_SIGNALS']),'screenshot_requests':out['screenshot_requests'],'outdir':str(od)},indent=2))
    return 0 if out['run_meta']['overall_status']!='ENGINE_ERROR' else 2

if __name__=='__main__':
    raise SystemExit(main())

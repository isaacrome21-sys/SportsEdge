# SportsEdge Automation Wrapper v1.1

Self-contained audit/orchestration release.

Key change from v1.0: DK price failure states are visually distinct (`MISSING_PRICE`, `STALE_PRICE`, `UNKNOWN_PRICE_FRESHNESS`) while remediation remains independent (`SCREENSHOT_REQUIRED`). Markets retain all simultaneous source failures in `issues`, and screenshot hints are never lost merely because another input is stale.

Included dependencies: `sportsedge_beta_v1_4.py`, validation registry v1.4, multi-market engine v1.2, BB v2 artifact, SB v2 artifact, live input manifest, and a local regression fixture/test.

Run regression test:

```bash
python test_runner_v1_1.py
```

Run wrapper:

```bash
python sportsedge_runner_v1_1.py live_snapshot.json --outdir sportsedge_run_output
```

## Registry correction 1.4.1

Measured-state authorization corrected: hits PASS_CAUTION (2.63 SE), total bases PASS (1.60), pitcher walks PASS_CAUTION (2.18), SGP PASS_GATED (2.79 same-team/same-path only), ER BLOCKED (3.25), SB BLOCKED_UNBUILT. RBI (1.28) and runs (2.34) are recorded as VALIDATED_NOT_DEPLOYED because this packaged runtime still uses the older joint-simulation marginals rather than the validated direct-threshold implementations.

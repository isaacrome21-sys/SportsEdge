#!/usr/bin/env python3
import argparse, json, math, os, hashlib
from typing import Dict, Any, List
import numpy as np
import pandas as pd
import joblib

from SportsEdge_MultiMarket_Engine_v1_2 import (
    GameRunInputs, CorrelatedRunMC, JointBatter, JointLineupMC,
    SharedTeamEffect, prob_to_american, american_to_prob,
    PitcherInputs, PitcherPropEngine, PitcherBBParams, PitcherBBEngine,
    PitcherERMixtureParams, PitcherERMixtureEngine, SGPLeg, SGPEngine
)

BETA_COEFS = {
    "intercept": 0.19512015,
    "starter_fip_edge_home": -0.01025177,
    "kbb_edge_home": 1.40900700,
    "lineup_woba_edge_home": 3.86646739,
    "opp_pct_edge_home": 0.07844380,
    "switch_pct_edge_home": -0.63527626,
}

VALIDATION_REGISTRY_FILENAME = "SportsEdge_Validation_Registry_v1_4.json"
BB_V2_FILENAME = "sportsedge_pitcher_bb_v2.joblib"
SB_V2_FILENAME = "sportsedge_hitter_sb_v2.joblib"

def _registry_path() -> str:
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), VALIDATION_REGISTRY_FILENAME)

def load_validation_registry() -> Dict[str,Any]:
    path=_registry_path()
    try:
        with open(path, "r", encoding="utf-8") as f:
            reg=json.load(f)
    except Exception as e:
        return {"schema_version":"ERROR","markets":{},"registry_error":f"validation registry unavailable: {e}"}
    if not isinstance(reg,dict) or not isinstance(reg.get("markets"),dict):
        return {"schema_version":"ERROR","markets":{},"registry_error":"validation registry malformed"}
    return reg



def _artifact_path(filename: str) -> str:
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), filename)

def load_bb_v2_artifact() -> Dict[str,Any]:
    try:
        obj=joblib.load(_artifact_path(BB_V2_FILENAME))
        if not isinstance(obj,dict) or not isinstance(obj.get("models"),dict) or not isinstance(obj.get("metadata"),dict):
            raise ValueError("malformed BB v2 artifact")
        if not obj["metadata"].get("all_common_thresholds_pass_2se",False):
            raise ValueError("BB v2 validation gate is not green")
        return obj
    except Exception as e:
        return {"metadata":{"artifact_error":str(e)},"models":{}}

BB_V2_ARTIFACT = load_bb_v2_artifact()

def load_sb_v2_artifact() -> Dict[str,Any]:
    try:
        obj=joblib.load(_artifact_path(SB_V2_FILENAME))
        if not isinstance(obj,dict) or not isinstance(obj.get("metadata"),dict) or obj.get("model") is None or obj.get("calibrator") is None:
            raise ValueError("malformed SB v2 artifact")
        if not obj["metadata"].get("all_common_thresholds_pass_2se",False):
            raise ValueError("SB v2 validation gate is not green")
        return obj
    except Exception as e:
        return {"metadata":{"artifact_error":str(e)}}

SB_V2_ARTIFACT = load_sb_v2_artifact()

def sb_v2_probability(profile: Dict[str,Any]) -> float:
    feats=SB_V2_ARTIFACT.get("metadata",{}).get("feature_list",[])
    if not feats or SB_V2_ARTIFACT.get("model") is None:
        raise ValueError("SB v2 artifact unavailable")
    nested=profile.get("sb_v2_features",{}) if isinstance(profile.get("sb_v2_features",{}),dict) else {}
    vals={}
    for f in feats:
        if f in nested: vals[f]=nested[f]
        elif f in profile: vals[f]=profile[f]
        else: raise ValueError(f"SB v2 missing live-parity feature: {f}")
    X=pd.DataFrame([{f:float(vals[f]) for f in feats}],columns=feats)
    raw=float(np.clip(SB_V2_ARTIFACT["model"].predict_proba(X)[:,1][0],1e-5,1-1e-5))
    lg=math.log(raw/(1-raw))
    return float(SB_V2_ARTIFACT["calibrator"].predict_proba(np.array([[lg]]))[:,1][0])

def bb_v2_probability(profile: Dict[str,Any], line: float, side: str) -> float:
    """Exact deployed pitcher-BB v2 path. Missing parity features fail closed."""
    key=str(float(line))
    modelrec=BB_V2_ARTIFACT.get("models",{}).get(key)
    if modelrec is None:
        raise ValueError(f"BB v2 unsupported line: {line}")
    feats=BB_V2_ARTIFACT.get("metadata",{}).get("feature_list",[])
    vals={}
    nested=profile.get("bb_v2_features",{}) if isinstance(profile.get("bb_v2_features",{}),dict) else {}
    for f in feats:
        if f in nested: vals[f]=nested[f]
        elif f in profile: vals[f]=profile[f]
        else: raise ValueError(f"BB v2 missing live-parity feature: {f}")
    X=pd.DataFrame([{f:float(vals[f]) for f in feats}],columns=feats)
    # BB v2 artifacts may store either a direct classifier or a {model, calibrator} record.
    if isinstance(modelrec, dict):
        mdl=modelrec.get("model")
        cal=modelrec.get("calibrator")
        if mdl is None:
            raise ValueError("BB v2 malformed model record")
        p0=float(mdl.predict_proba(X)[:,1][0])
        if cal is not None:
            from scipy.special import logit
            p_over=float(cal.predict_proba([[float(logit(np.clip(p0,1e-6,1-1e-6)))]])[:,1][0])
        else:
            p_over=p0
    else:
        p_over=float(modelrec.predict_proba(X)[:,1][0])
    if side.lower()=="over": return p_over
    if side.lower()=="under": return 1.0-p_over
    raise ValueError("BB v2 requires side=over or under")

VALIDATION_REGISTRY = load_validation_registry()
VALIDATION_STATUS = {k:v.get("status","UNVALIDATED") for k,v in VALIDATION_REGISTRY.get("markets",{}).items()}

def validation_record(market: str) -> Dict[str,Any]:
    return VALIDATION_REGISTRY.get("markets",{}).get(market,{"status":"UNVALIDATED","official_eligible":False,"reason":"market absent from validation registry"})

PLAYER_MARKETS = {"hr","home run","home_runs","hits","hit","total bases","tb","rbi","runs","run","sb","stolen base","stolen bases"}
FIRST_INNING_MARKETS = {"nrfi","yrfi","nrfi/yrfi","1st inning runs","first inning runs"}
F5_MARKETS = {"f5 moneyline","f5 ml","first 5 moneyline","f5 run line","f5 rl","first 5 run line","f5 total","first 5 total","f5 team total","first 5 team total"}

PITCHER_MARKETS = {
    "pitcher strikeouts","pitcher k","pitcher ks","strikeouts","ks",
    "pitcher outs","outs recorded","outs",
    "pitcher hits","hits allowed","pitcher hits allowed",
    "pitcher walks","walks allowed","pitcher bb","bb",
    "pitcher earned runs","earned runs","pitcher er","er",
}


def logistic(z: float) -> float:
    return 1.0 / (1.0 + math.exp(-z))


def beta_ml_home_p(features: Dict[str,float]) -> float:
    z = BETA_COEFS["intercept"]
    for k, c in BETA_COEFS.items():
        if k == "intercept":
            continue
        if k not in features:
            raise ValueError(f"Missing beta ML feature: {k}")
        z += c * float(features[k])
    return logistic(z)


def decimal_from_american(o: float) -> float:
    return 1.0 + (100.0/abs(o) if o < 0 else o/100.0)


def boosted_american(o: float, boost_pct: float) -> float:
    d = decimal_from_american(o)
    bd = 1.0 + (d - 1.0) * (1.0 + boost_pct/100.0)
    if bd >= 2.0:
        return (bd - 1.0) * 100.0
    return -100.0 / (bd - 1.0)


def ev_pct(p: float, american: float) -> float:
    return 100.0 * (p * decimal_from_american(american) - 1.0)

def ev_pct_with_push(p_win: float, p_push: float, american: float) -> float:
    """EV% for markets where a push returns stake.
    p_win + p_push <= 1; remainder is loss probability.
    """
    p_win=float(p_win); p_push=float(p_push)
    if p_win < 0 or p_push < 0 or p_win + p_push > 1.0000001:
        raise ValueError('invalid win/push probabilities')
    profit = decimal_from_american(american)-1.0
    p_loss = 1.0-p_win-p_push
    return 100.0*(p_win*profit - p_loss)

def fair_american_with_push(p_win: float, p_push: float) -> float:
    """Break-even American odds conditional on non-push outcomes."""
    denom=1.0-p_push
    if denom <= 0: raise ValueError('all outcomes push')
    return prob_to_american(p_win/denom)


def min_american_for_ev(p: float, target_ev_pct: float=0.0) -> float:
    req_d = (1.0 + target_ev_pct/100.0) / p
    if req_d >= 2.0:
        return 100.0 * (req_d - 1.0)
    return -100.0 / (req_d - 1.0)


def market_reference_prob(row: Dict[str,Any]) -> float:
    """Use 2-way no-vig probability when opposite_odds is supplied; else raw implied."""
    p=american_to_prob(float(row["dk_odds"]))
    opp=row.get("opposite_odds")
    if opp is None:
        return p
    q=american_to_prob(float(opp))
    den=p+q
    if den<=0: raise ValueError("invalid two-way odds")
    return p/den

def freshness_gate(row: Dict[str,Any]) -> str:
    """Derive freshness from explicit age when available; fallback to supplied status."""
    age=row.get("price_age_seconds")
    max_age=row.get("max_price_age_seconds")
    if age is not None and max_age is not None:
        return "FRESH" if float(age)<=float(max_age) else "STALE"
    return str(row.get("freshness","FRESH")).upper()


def calibrate_run_split(target_home_p: float, total_mu: float, vmr: float=2.226,
                        shared_sigma: float=0.0, seed: int=91026,
                        search_sims: int=7000, final_sims: int=50000) -> Dict[str,Any]:
    if not (0.05 < target_home_p < 0.95):
        raise ValueError("target_home_p must be between .05 and .95")
    if total_mu <= 3:
        raise ValueError("model_total_mu looks invalid")
    lo, hi = 0.25, 0.75
    for i in range(18):
        share = (lo + hi) / 2
        mu_h = total_mu * share
        mu_a = total_mu - mu_h
        r = CorrelatedRunMC(search_sims).price_game(GameRunInputs(mu_a, mu_h, vmr, shared_sigma, seed+i))
        if r["p_home_ml"] < target_home_p:
            lo = share
        else:
            hi = share
    share = (lo + hi) / 2
    mu_h, mu_a = total_mu * share, total_mu * (1-share)
    paths = CorrelatedRunMC(final_sims).simulate(GameRunInputs(mu_a, mu_h, vmr, shared_sigma, seed+1000))
    home, away = paths["home"], paths["away"]
    ties = home == away
    p_home = float(np.mean(home > away) + 0.5*np.mean(ties))
    return {"mu_home":mu_h, "mu_away":mu_a, "p_home_ml_mc":p_home, "paths":paths}


def market_outcome(paths: Dict[str,np.ndarray], market: str, selection: str, line: Any) -> Dict[str,float]:
    home, away, total = paths["home"], paths["away"], paths["total"]
    margin = home - away
    m, s = market.lower(), selection.lower()
    if m in ("moneyline","ml"):
        # MLB ML has no ties after extras; MC ties are split as neutral calibration mass.
        ties = home == away
        ph = float(np.mean(home > away) + 0.5*np.mean(ties))
        return {"p_win": ph if s in ("home","sd","san diego padres","padres") else 1-ph, "p_push":0.0}
    if m in ("run line","runline","rl","spread","spreads"):
        ln = float(line)
        x = margin + ln if s in ("home","sd","san diego padres","padres") else -margin + ln
        return {"p_win":float(np.mean(x>0)), "p_push":float(np.mean(x==0))}
    if m in ("total","totals"):
        ln = float(line)
        return {"p_win":float(np.mean(total>ln)) if s=="over" else float(np.mean(total<ln)), "p_push":float(np.mean(total==ln))}
    if m in ("team total","team_total","tt"):
        ln=float(line)
        arr=home if ("home" in s or "padres" in s or s.startswith("sd")) else away
        return {"p_win":float(np.mean(arr>ln)) if "over" in s else float(np.mean(arr<ln)), "p_push":float(np.mean(arr==ln))}
    raise ValueError(f"Unsupported game market {market}/{selection}/{line}")

def market_prob(paths: Dict[str,np.ndarray], market: str, selection: str, line: Any) -> float:
    return market_outcome(paths,market,selection,line)["p_win"]

def _load_model_artifact(path: str, expected_version_prefix: str):
    if not path or not os.path.exists(path):
        raise ValueError(f"missing model artifact: {path}")
    art=joblib.load(path)
    if not str(art.get("version","")).startswith(expected_version_prefix):
        raise ValueError(f"unexpected model artifact version: {art.get('version')}")
    return art

def build_f5_paths_from_features(cfg: Dict[str,Any]) -> Dict[str,np.ndarray]:
    feats=cfg.get("f5_features")
    if not feats: raise ValueError("missing independent F5 features")
    art=_load_model_artifact(cfg.get("f5_model_path","/mnt/data/sportsedge_f5_model_v1.joblib"),"F5_V1")
    model=art["model"]; alpha=float(art["nb_alpha"]); n=int(cfg.get("f5_sims",cfg.get("game_sims",50000))); seed=int(cfg.get("seed",91026))+5000
    rows=[]
    for side,home_half in (("away",0),("home",1)):
        row=dict(feats[side]); row["home_half"]=home_half
        rows.append(row)
    frame=pd.DataFrame(rows)
    need=list(art["numeric_features"])+list(art["categorical_features"]); miss=[c for c in need if c not in frame.columns]
    if miss: raise ValueError(f"missing F5 live features: {miss}")
    mu=model.predict(frame[need]); rng=np.random.default_rng(seed)
    def draw(m):
        if alpha<=1e-12: return rng.poisson(m,size=n)
        lam=rng.gamma(shape=1.0/alpha,scale=alpha*m,size=n); return rng.poisson(lam)
    away=draw(float(mu[0])); home=draw(float(mu[1]))
    return {"away":away,"home":home,"total":away+home,"mu_away":float(mu[0]),"mu_home":float(mu[1])}

def predict_first_inning_from_features(cfg: Dict[str,Any]) -> Dict[str,float]:
    feats=cfg.get("first_inning_features")
    if not feats: raise ValueError("missing direct first-inning features")
    art=_load_model_artifact(cfg.get("nrfi_model_path","/mnt/data/sportsedge_nrfi_model_v1.joblib"),"NRFI_V1")
    need=list(art["numeric_features"])+list(art["categorical_features"]); frame=pd.DataFrame([feats]); miss=[c for c in need if c not in frame.columns]
    if miss: raise ValueError(f"missing first-inning live features: {miss}")
    base=float(art["model"].predict_proba(frame[need])[:,1][0])
    st=cfg.get("first_inning_online_state") or {}
    n=float(st.get("prior_games",0)); cy=float(st.get("prior_yrfi_sum",0)); cp=float(st.get("prior_base_p_sum",0)); strength=float(art.get("online_strength",1600))
    adj=(cy-cp)/(strength+n) if (strength+n)>0 else 0.0
    p=float(np.clip(base+adj,.02,.98))
    return {"p_yrfi":p,"base_p_yrfi":base,"online_adjustment":adj}

def independent_period_outcome(cfg: Dict[str,Any], row: Dict[str,Any], period: str) -> Dict[str,float]:
    """Price F5 or first inning only from dedicated period inputs. Never derive by scaling FG."""
    key = "f5_paths" if period=="f5" else "first_inning"
    if period=="f5":
        obj=cfg.get(key)
        if not obj:
            obj=build_f5_paths_from_features(cfg)
        if "home" in obj and "away" in obj:
            paths={"home":np.asarray(obj["home"]),"away":np.asarray(obj["away"])}
            paths["total"]=paths["home"]+paths["away"]
            m=row["market"].lower().replace("first 5 ","f5 ")
            if "moneyline" in m or m=="f5 ml":
                h,a=paths["home"],paths["away"]; ties=h==a
                ph=float(np.mean(h>a)+0.5*np.mean(ties))
                home_sel=str(row["selection"]).lower() in ("home","sd","san diego padres","padres")
                return {"p_win":ph if home_sel else 1-ph,"p_push":0.0}
            if "team total" in m:
                base="team total"
            else:
                base="run line" if "run line" in m or m=="f5 rl" else "total"
            return market_outcome(paths,base,row["selection"],row.get("line"))
        raise ValueError("F5 model output must contain same-path home/away arrays")
    obj=cfg.get(key)
    if not obj:
        obj=predict_first_inning_from_features(cfg)
    p_yrfi=float(obj.get("p_yrfi")) if obj.get("p_yrfi") is not None else None
    if p_yrfi is None and obj.get("p_away_scores") is not None and obj.get("p_home_scores") is not None:
        # Combine only when a dependence correction is explicitly supplied.
        rho=float(obj.get("joint_dependence_adjustment",0.0))
        pa=float(obj["p_away_scores"]); ph=float(obj["p_home_scores"])
        p_yrfi=pa+ph-pa*ph+rho
    if p_yrfi is None: raise ValueError("first-inning output requires p_yrfi or both half-inning probabilities")
    p_yrfi=max(0.0,min(1.0,p_yrfi))
    sel=str(row.get("selection",row.get("side",""))).lower()
    wants_nrfi = "nrfi" in row["market"].lower() or sel in ("nrfi","under","no")
    return {"p_win":1.0-p_yrfi if wants_nrfi else p_yrfi,"p_push":0.0}


def build_joint_lineup(bats: List[Dict[str,Any]]) -> List[JointBatter]:
    return [JointBatter(
        name=b["name"], pa_mean=float(b.get("pa_mean",4.2)),
        p_single=float(b["p_single"]), p_double=float(b["p_double"]),
        p_triple=float(b.get("p_triple",0.0)), p_hr=float(b["p_hr"]),
        p_bb=float(b["p_bb"]), p_hbp=float(b.get("p_hbp",0.0)),
        p_sb_attempt_given_1b=float(b.get("p_sb_attempt_given_1b",0.03)),
        p_sb_success=float(b.get("p_sb_success",0.75))
    ) for b in bats]


def build_hitter_simulations(cfg: Dict[str,Any]) -> Dict[str,Any]:
    sims={}
    for team_key in ("away_batters","home_batters"):
        bats=cfg.get(team_key) or []
        if not bats: continue
        sim=JointLineupMC(int(cfg.get("hitter_sims",50000))).simulate_team(
            build_joint_lineup(bats),SharedTeamEffect(float(cfg.get("shared_team_sigma",0.20))),
            team_pa_mean=float(cfg.get(f"{team_key}_team_pa_mean",38.0)),team_pa_sd=float(cfg.get("team_pa_sd",3.1)),
            seed=int(cfg.get("seed",91026))+(0 if team_key.startswith("away") else 1))
        sims[team_key]={"batters":bats,"sim":sim,"index":{b["name"]:i for i,b in enumerate(bats)}}
    return sims

def price_hitter_markets(cfg: Dict[str,Any], simulations: Dict[str,Any]=None) -> Dict[str,Dict[str,float]]:
    results={}; simulations=simulations or build_hitter_simulations(cfg)
    for team_key,obj in simulations.items():
        bats=obj["batters"]; sim=obj["sim"]
        for j,b in enumerate(bats):
            results[b["name"]]={
                "p_hit_1plus":float(np.mean(sim["hits"][:,j]>=1)),"p_hit_2plus":float(np.mean(sim["hits"][:,j]>=2)),"p_hit_3plus":float(np.mean(sim["hits"][:,j]>=3)),
                "p_tb_1plus":float(np.mean(sim["tb"][:,j]>=1)),"p_tb_2plus":float(np.mean(sim["tb"][:,j]>=2)),"p_tb_3plus":float(np.mean(sim["tb"][:,j]>=3)),"p_tb_4plus":float(np.mean(sim["tb"][:,j]>=4)),
                "p_hr":float(np.mean(sim["hr"][:,j]>=1)),"p_rbi":float(np.mean(sim["rbi"][:,j]>=1)),"p_run":float(np.mean(sim["runs"][:,j]>=1)),"p_sb":float(np.mean(sim["sb"][:,j]>=1)),"_profile":dict(b)}
    return results

def _sgp_hitter_leg(simulations: Dict[str,Any], leg: Dict[str,Any]):
    name=leg["selection"]; m=canonical_market_name(leg["market"]); line=float(leg.get("line",0.5)); side=str(leg.get("side","over")).lower()
    found=None
    for tk,obj in simulations.items():
        if name in obj["index"]: found=(tk,obj); break
    if not found: raise ValueError(f"SGP hitter not found: {name}")
    tk,obj=found; j=obj["index"][name]; sim=obj["sim"]
    stat_map={"hits":"hits","total bases":"tb","hr":"hr","rbi":"rbi","runs":"runs","sb":"sb"}
    if m not in stat_map: raise ValueError(f"SGP leg not same-path hitter supported: {m}")
    arr=sim[stat_map[m]][:,j]
    return tk, SGPLeg(key=f"{name}:{m}:{line}:{side}",values=arr,threshold=line,direction=side)

def price_sgps(cfg: Dict[str,Any], simulations: Dict[str,Any]) -> List[Dict[str,Any]]:
    out=[]
    for sgp in cfg.get("sgps",[]) or []:
        try:
            legs=[]; teams=[]
            for raw in sgp["legs"]:
                leg_market=canonical_market_name(raw.get("market",""))
                leg_rec=validation_record(leg_market)
                if not bool(leg_rec.get("official_eligible",False)):
                    raise ValueError(f"SGP leg blocked by validation registry: {leg_market} ({leg_rec.get('status','UNVALIDATED')})")
                if leg_market in ("hits","total bases") and abs(float(cfg.get("shared_team_sigma",0.20))-0.20)>1e-9:
                    raise ValueError(f"SGP {leg_market} leg requires shared_team_sigma=0.20 validation parity")
                tk,leg=_sgp_hitter_leg(simulations,raw); teams.append(tk); legs.append(leg)
            if len(set(teams))!=1:
                raise ValueError("cross-team/cross-engine SGP not yet on one shared game path")
            priced=SGPEngine.price(legs); p=float(priced["p_joint"]); odds=float(sgp["dk_odds"]); ref=market_reference_prob(sgp); ev=ev_pct(p,odds); edge=100*(p-ref)
            row={"market":"sgp","selection":sgp.get("selection"," + ".join(l.key for l in legs)),"line":None,"dk_odds":odds,**{k:v for k,v in sgp.items() if k not in ("legs","market","selection","line","dk_odds")}}
            g=grade_bet(row,p,ev,ev,edge)
            dec="BLOCKED" if g.get("grade")=="BLOCK" else ("PLAY" if g["official"] else ("WATCH" if g["score"]>=70 and ev>0 else "PASS"))
            units=fractional_kelly_units(p,odds,g["score"]) if g["official"] else 0.0
            out.append({**row,"model_p":p,"fair_odds":priced["fair_american"],"market_reference_p":ref,"edge_vs_market_pp":edge,"raw_ev_pct":ev,"quality_score":g["score"],"grade":g["grade"],"units":units,"decision":dec,"dependence_ratio":priced["dependence_ratio"],"pairwise_correlations":priced["pairwise_corr"],"naive_independence_p":priced["naive_independence_p"]})
        except Exception as e:
            out.append({"market":"sgp","selection":sgp.get("selection","SGP"),"dk_odds":sgp.get("dk_odds"),"decision":"BLOCKED","grade":"BLOCK","quality_score":0,"units":0,"reason":str(e)})
    return out


def resolve_player_market_prob(player_results: Dict[str,Dict[str,float]], row: Dict[str,Any]) -> float:
    name = row["selection"]
    if name not in player_results:
        raise ValueError(f"No hitter profile for {name}")
    m, line = row["market"].lower(), float(row.get("line",0.5))
    pr = player_results[name]
    if m in ("hr","home run","home_runs") and line == 0.5: return pr["p_hr"]
    if m in ("hits","hit"):
        return pr[{0.5:"p_hit_1plus",1.5:"p_hit_2plus",2.5:"p_hit_3plus"}[line]]
    if m in ("total bases","tb"):
        return pr[{0.5:"p_tb_1plus",1.5:"p_tb_2plus",2.5:"p_tb_3plus",3.5:"p_tb_4plus"}[line]]
    if m == "rbi" and line == 0.5: return pr["p_rbi"]
    if m in ("runs","run") and line == 0.5: return pr["p_run"]
    if m in ("sb","stolen base","stolen bases") and line == 0.5: return sb_v2_probability(pr.get("_profile",{}))
    raise ValueError(f"Unsupported player market/line: {m} {line}")


def build_pitcher_results(cfg: Dict[str,Any]) -> Dict[str,Dict[str,np.ndarray]]:
    out = {}
    n = int(cfg.get("pitcher_sims",50000))
    for p in cfg.get("pitchers",[]) or []:
        name = p["name"]
        base_k=float(p["k_rate"])
        opp_k=p.get("opp_lineup_k_rate")
        league_k=float(p.get("league_k_rate",0.225))
        opp_coef=float(p.get("opp_k_coef",1.02))
        # Historical K rebuild found near 1:1 opponent-lineup K pass-through.
        # Apply on logit scale to keep probability bounded and preserve the pitcher's own baseline skill.
        if opp_k is not None:
            def _logit(x):
                x=min(max(float(x),1e-6),1-1e-6); return math.log(x/(1-x))
            k_rate=logistic(_logit(base_k)+opp_coef*(_logit(float(opp_k))-_logit(league_k)))
        else:
            k_rate=base_k
        generic = PitcherPropEngine(n).simulate(PitcherInputs(
            name=name,
            batters_faced_mean=float(p["bf_mean"]),
            k_rate=k_rate,
            bb_rate=float(p.get("bb_rate",0.08)),
            hit_rate=float(p["hit_rate"]),
            er_rate_per_bf=float(p.get("er_rate_per_bf",0.11)),
            outs_mean=float(p["outs_mean"]),
            outs_sd=float(p.get("outs_sd",3.0)),
            overdispersion=float(p.get("overdispersion",0.08))
        ), seed=int(cfg.get("seed",91026))+100+len(out))
        bb = PitcherBBEngine(n).simulate(PitcherBBParams(
            bf_mean=float(p["bf_mean"]), bb_rate=float(p["bb_rate"]),
            bf_sd=float(p.get("bf_sd",4.0))
        ), seed=int(cfg.get("seed",91026))+200+len(out))
        er = PitcherERMixtureEngine(n).simulate(PitcherERMixtureParams(
            bf_mean=float(p["bf_mean"]),
            normal_er_per_bf=float(p["normal_er_per_bf"]),
            blowup_er_per_bf=float(p["blowup_er_per_bf"]),
            blowup_prob=float(p["blowup_prob"]),
            bf_sd=float(p.get("bf_sd",4.0)),
            normal_vmr=float(p.get("normal_vmr",1.25)),
            blowup_vmr=float(p.get("blowup_vmr",1.60))
        ), seed=int(cfg.get("seed",91026))+300+len(out))
        generic["bb"] = bb
        generic["er"] = er
        generic["_profile"] = dict(p)
        out[name] = generic
    return out


def resolve_pitcher_market_prob(pitcher_results: Dict[str,Dict[str,np.ndarray]], row: Dict[str,Any]) -> float:
    name = row["selection"]
    if name not in pitcher_results:
        raise ValueError(f"No pitcher profile for {name}")
    m, line = row["market"].lower(), float(row["line"])
    side = str(row.get("side","over")).lower()
    if m in ("pitcher strikeouts","pitcher k","pitcher ks","strikeouts","ks"): stat="k"
    elif m in ("pitcher outs","outs recorded","outs"): stat="outs"
    elif m in ("pitcher hits","hits allowed","pitcher hits allowed"): stat="hits"
    elif m in ("pitcher walks","walks allowed","pitcher bb","bb"):
        # v2 BB is a direct threshold probability model with exact live feature parity.
        # Do not fall back to the old count simulation when v2 features are missing.
        return bb_v2_probability(pitcher_results[name].get("_profile",{}), line, side)
    elif m in ("pitcher earned runs","earned runs","pitcher er","er"): stat="er"
    else: raise ValueError(f"Unsupported pitcher market: {m}")
    arr = pitcher_results[name][stat]
    if side == "over": return float(np.mean(arr > line))
    if side == "under": return float(np.mean(arr < line))
    raise ValueError("Pitcher prop row requires side=over or under")


def canonical_market_name(market: str) -> str:
    m = market.lower()
    if m in ("ml","moneyline"): return "moneyline"
    if m in ("run line","runline","rl","spread","spreads"): return "run line"
    if m in ("total","totals"): return "total"
    if m in ("team total","team_total","tt"): return "team total"
    if m in ("f5 moneyline","f5 ml","first 5 moneyline"): return "f5 moneyline"
    if m in ("f5 run line","f5 rl","first 5 run line"): return "f5 run line"
    if m in ("f5 total","first 5 total"): return "f5 total"
    if m in ("f5 team total","first 5 team total"): return "f5 team total"
    if m in FIRST_INNING_MARKETS: return "nrfi/yrfi"
    if m in ("sgp","same game parlay"): return "sgp"
    if m in ("pitcher strikeouts","pitcher k","pitcher ks","strikeouts","ks"): return "pitcher strikeouts"
    if m in ("pitcher outs","outs recorded","outs"): return "pitcher outs"
    if m in ("pitcher hits","hits allowed","pitcher hits allowed"): return "pitcher hits"
    if m in ("pitcher walks","walks allowed","pitcher bb","bb"): return "pitcher walks"
    if m in ("pitcher earned runs","earned runs","pitcher er","er"): return "pitcher earned runs"
    if m in ("hits","hit"): return "hits"
    if m in ("total bases","tb"): return "total bases"
    if m in ("hr","home run","home_runs"): return "hr"
    if m == "rbi": return "rbi"
    if m in ("runs","run"): return "runs"
    if m in ("sb","stolen base","stolen bases"): return "sb"
    return m


def grade_bet(row: Dict[str,Any], p: float, raw_ev: float, boosted_ev: float, edge_pp: float) -> Dict[str,Any]:
    """Bet-quality score, NOT a probability/confidence percentage."""
    market = canonical_market_name(row["market"])
    vrec = validation_record(market)
    vstat = vrec.get("status","UNVALIDATED")
    if not bool(vrec.get("official_eligible",False)):
        return {"score":0,"grade":"BLOCK","official":False,"validation":vstat,
                "reason":vrec.get("reason","market is not authorized by validation registry")}

    # Base quality = 50. Positive EV/edge must earn promotion; penalties can only reduce it.
    effective_ev = max(raw_ev, boosted_ev if row.get("boost_pct") else raw_ev)
    score = 60.0 + min(max(effective_ev, -10.0), 15.0)*2.5 + min(max(edge_pp, -8.0), 10.0)*1.5

    # Validation quality.
    if "CAUTION" in vstat: score -= 5.0
    if "BETA" in vstat: score -= 3.0
    if "GATED" in vstat: score -= 2.0

    # Operational certainty / freshness.
    starter = str(row.get("starter_status","CONFIRMED")).upper()
    lineup = str(row.get("lineup_status","CONFIRMED")).upper()
    weather = str(row.get("weather_status","OK")).upper()
    freshness = freshness_gate(row)
    if starter != "CONFIRMED": score -= 15.0
    if market in PLAYER_MARKETS and lineup != "CONFIRMED": score -= 12.0
    elif lineup not in ("CONFIRMED","PROJECTED"): score -= 8.0
    if weather == "CAUTION": score -= 4.0
    if weather in ("VETO","BLOCKED"): score -= 30.0
    if freshness in ("STALE","EXPIRED"): score -= 20.0
    elif freshness in ("UNKNOWN","TBD"): score -= 8.0

    # Explicit uncertainty/correlation penalties supplied by execution layer.
    score -= float(row.get("uncertainty_penalty",0.0) or 0.0)
    score -= float(row.get("correlation_penalty",0.0) or 0.0)
    score = max(0.0, min(100.0, score))

    # Never promote a bet that doesn't clear actual EV gates.
    boost_only = raw_ev < 3.0 and bool(row.get("boost_pct")) and boosted_ev >= 3.0
    ev_gate = raw_ev >= 3.0 or boost_only
    hard_gate = starter == "CONFIRMED" and weather not in ("VETO","BLOCKED") and freshness not in ("STALE","EXPIRED")
    if market in PLAYER_MARKETS or market in ("f5 moneyline","f5 run line","f5 total","f5 team total","nrfi/yrfi"):
        hard_gate = hard_gate and lineup == "CONFIRMED"

    if score >= 90: grade="A+"
    elif score >= 85: grade="A"
    elif score >= 80: grade="B+"
    elif score >= 75: grade="B"
    elif score >= 72.5: grade="B-"
    elif score >= 70: grade="C+"
    elif score >= 65: grade="C"
    else: grade="PASS"

    official = bool(ev_gate and hard_gate and score >= 72.5)
    if boost_only and grade in ("A+","A"):
        grade = "B+"  # Promo-created edge is real EV but lower robustness than raw edge.
        score = min(score,84.9)
        official = hard_gate and score >= 72.5
    return {"score":round(score,1),"grade":grade,"official":official,"validation":vstat}


def fractional_kelly_units(p: float, odds: float, grade_score: float, boost_only: bool=False) -> float:
    d = decimal_from_american(odds)
    b = d - 1.0
    q = 1.0 - p
    full = max(0.0, (b*p-q)/b)
    # Conservative 1/4 Kelly with a grading cap, expressed in bankroll units where 1u = 1% bankroll.
    units = full * 25.0
    cap = 1.25 if grade_score >= 90 else 1.0 if grade_score >= 85 else 0.75 if grade_score >= 80 else 0.5 if grade_score >= 75 else 0.35
    if boost_only: cap = min(cap,0.5)
    return round(min(units,cap),2)



def audit_market_coverage(rows: List[Dict[str,Any]], cfg: Dict[str,Any]) -> Dict[str,Any]:
    required=cfg.get("required_market_families") or [
        "moneyline","run line","total","team total","f5 moneyline","f5 run line","f5 total","f5 team total",
        "nrfi/yrfi","pitcher strikeouts","pitcher outs","pitcher hits","pitcher walks",
        "pitcher earned runs","hits","total bases","hr","rbi","runs","sb","sgp"
    ]
    present=set(canonical_market_name(r.get("market","")) for r in rows)
    # SGP may be represented in a separate config collection.
    if cfg.get("sgps"): present.add("sgp")
    missing=[m for m in required if m not in present]
    return {"required":required,"present":sorted(present),"missing":missing,"complete":len(missing)==0}

def run(cfg: Dict[str,Any]) -> Dict[str,Any]:
    home_anchor = beta_ml_home_p(cfg["ml_features"])
    runfit = calibrate_run_split(home_anchor, float(cfg["model_total_mu"]),
                                 float(cfg.get("dispersion_vmr",2.226)),
                                 float(cfg.get("shared_sigma",0.0)),
                                 int(cfg.get("seed",91026)),
                                 int(cfg.get("search_sims",7000)), int(cfg.get("game_sims",50000)))
    hitter_sims = build_hitter_simulations(cfg)
    hitter_res = price_hitter_markets(cfg,hitter_sims)
    pitcher_res = build_pitcher_results(cfg)
    rows = []
    for r0 in cfg.get("markets",[]):
        r = dict(r0)
        market = r["market"]
        try:
            ml = market.lower()
            p_push=0.0
            if ml in PLAYER_MARKETS:
                cm=canonical_market_name(ml)
                if cm in ("hits","total bases") and abs(float(cfg.get("shared_team_sigma",0.20))-0.20)>1e-9:
                    raise ValueError(f"{cm} validation parity requires shared_team_sigma=0.20")
                p = resolve_player_market_prob(hitter_res,r)
            elif ml in PITCHER_MARKETS:
                p = resolve_pitcher_market_prob(pitcher_res,r)
            elif ml in F5_MARKETS:
                oc=independent_period_outcome(cfg,r,"f5"); p,p_push=oc["p_win"],oc["p_push"]
            elif ml in FIRST_INNING_MARKETS:
                oc=independent_period_outcome(cfg,r,"first_inning"); p,p_push=oc["p_win"],oc["p_push"]
            else:
                oc=market_outcome(runfit["paths"], market, r["selection"], r.get("line")); p,p_push=oc["p_win"],oc["p_push"]
            odds = float(r["dk_odds"])
            boost = float(r.get("boost_pct") or 0.0)
            fair = fair_american_with_push(p,p_push) if p_push>0 else prob_to_american(p)
            raw_ev = ev_pct_with_push(p,p_push,odds) if p_push>0 else ev_pct(p,odds)
            bo = boosted_american(odds,boost) if boost else odds
            bev = ev_pct_with_push(p,p_push,bo) if p_push>0 else ev_pct(p,bo)
            nonpush_p=p/(1.0-p_push) if p_push<1 else 0.0
            market_ref_p=market_reference_prob(r)
            edge_pp = 100*(nonpush_p-market_ref_p)
            g = grade_bet(r,p,raw_ev,bev,edge_pp)
            boost_only = raw_ev < 3.0 and boost and bev >= 3.0
            if g.get("grade") == "BLOCK":
                decision = "BLOCKED"
                units = 0.0
            elif g["official"]:
                decision = "BOOST_PLAY" if boost_only else "PLAY"
                units = fractional_kelly_units(p,bo if boost_only else odds,g["score"],bool(boost_only))
            else:
                decision = "WATCH" if g["score"] >= 70 and max(raw_ev,bev) > 0 else "PASS"
                units = 0.0
            rows.append({**r,"model_p":p,"push_p":p_push,"fair_odds":fair,"market_reference_p":market_ref_p,"edge_vs_market_pp":edge_pp,"edge_vs_implied_pp":edge_pp,
                         "raw_ev_pct":raw_ev,"boosted_odds":bo,"boosted_ev_pct":bev,
                         "min_price_0ev":min_american_for_ev(p,0),"quality_score":g["score"],
                         "grade":g["grade"],"validation_status":g.get("validation"),
                         "units":units,"decision":decision})
        except Exception as e:
            rows.append({**r,"decision":"BLOCKED","grade":"BLOCK","quality_score":0,"units":0,"reason":str(e)})
    sgp_rows=price_sgps(cfg,hitter_sims)
    rows.extend(sgp_rows)
    coverage=audit_market_coverage(rows,cfg)
    return {
        "model":"SportsEdge Beta v1.4 — evidence registry + deployable BB v2 + frozen ML anchor + joint MC",
        "home_ml_anchor_p":home_anchor,
        "mc_home_p":runfit["p_home_ml_mc"],
        "mu_home":runfit["mu_home"],"mu_away":runfit["mu_away"],
        "game_sims":int(cfg.get("game_sims",50000)),
        "hitter_sims":int(cfg.get("hitter_sims",50000)),
        "pitcher_sims":int(cfg.get("pitcher_sims",50000)),
        "markets":rows,
        "hitter_probabilities":hitter_res,
        "audit":{
            "sportsbook_implied_used_as_model_p":False,
            "validation_registry":VALIDATION_REGISTRY_FILENAME,
            "validation_registry_loaded":VALIDATION_REGISTRY.get("schema_version") != "ERROR",
            "validation_registry_error":VALIDATION_REGISTRY.get("registry_error"),
            "manual_prices_only_after_model":True,
            "grade_is_probability":False,
            "grade_threshold_official":72.5,
            "display_floor":"B-",
            "raw_ev_threshold_pct":3.0,
            "pitcher_profiles_present":bool(pitcher_res),
            "hitter_profiles_present":bool(hitter_res),
            "push_aware_ev":True,
            "f5_requires_independent_paths":True,
            "f5_live_artifact_supported":True,
            "nrfi_requires_direct_first_inning_output":True,
            "nrfi_live_artifact_supported":True,
            "k_uses_opponent_lineup_adjustment_when_present":True,
            "two_way_novig_when_opposite_odds_present":True,
            "market_coverage":coverage,
            "sgp_same_path_only":True,
        }
    }


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("config")
    ap.add_argument("-o","--output",default="sportsedge_beta_output.json")
    a=ap.parse_args()
    with open(a.config) as f: cfg=json.load(f)
    out=run(cfg)
    with open(a.output,"w") as f: json.dump(out,f,indent=2)
    print(json.dumps(out,indent=2))

if __name__=="__main__":
    main()

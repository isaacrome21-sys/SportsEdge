
"""
SportsEdge Multi-Market Research Engine v1.1
Built 2026-08-09
Revised 2026-08-09 — workload + batting-order variance fixes

PURPOSE
-------
Research/validation scaffold for:
- run line
- team totals
- F5 sides/totals/team totals
- NRFI/YRFI
- pitcher K/outs/hits/ER/BB
- hitter hits/TB/HR/RBI/runs/SB

IMPORTANT
---------
This module is intentionally fail-closed:
- It does not declare any market production-ready.
- It requires explicit model inputs.
- It exposes validation helpers (Brier/log loss/calibration).
- Promotion to OFFICIAL requires historical walk-forward validation by market.

The already-validated SportsEdge ML anchor and MC_V1 remain separate.
"""

from dataclasses import dataclass
from typing import Dict, Optional, Tuple, List
import math
import numpy as np

EPS = 1e-12

def american_to_prob(odds: float) -> float:
    return (-odds) / ((-odds) + 100.0) if odds < 0 else 100.0 / (odds + 100.0)

def prob_to_american(p: float) -> float:
    p = min(max(float(p), EPS), 1-EPS)
    if p >= 0.5:
        return -100.0 * p / (1.0-p)
    return 100.0 * (1.0-p) / p

def no_vig_two_way(odds_a: float, odds_b: float) -> Tuple[float, float]:
    pa, pb = american_to_prob(odds_a), american_to_prob(odds_b)
    s = pa + pb
    return pa/s, pb/s

def brier(y: np.ndarray, p: np.ndarray) -> float:
    y = np.asarray(y, dtype=float)
    p = np.asarray(p, dtype=float)
    return float(np.mean((p-y)**2))

def logloss(y: np.ndarray, p: np.ndarray) -> float:
    y = np.asarray(y, dtype=float)
    p = np.clip(np.asarray(p, dtype=float), EPS, 1-EPS)
    return float(-np.mean(y*np.log(p) + (1-y)*np.log(1-p)))

@dataclass
class GameRunInputs:
    mu_away: float
    mu_home: float
    # variance/mean target for each team's marginal run distribution
    dispersion_vmr: float = 2.226
    # shared environment volatility; 0 => independent
    shared_sigma: float = 0.0
    seed: int = 0

@dataclass
class PitcherInputs:
    name: str
    batters_faced_mean: float
    k_rate: float
    bb_rate: float
    hit_rate: float
    er_rate_per_bf: float
    outs_mean: float
    outs_sd: float = 3.0
    overdispersion: float = 0.08

@dataclass
class BatterInputs:
    name: str
    pa_mean: float
    p_single: float
    p_double: float
    p_triple: float
    p_hr: float
    p_bb: float
    p_hbp: float = 0.0
    # conditional probabilities tied to reaching/scoring opportunities
    p_run_given_onbase: float = 0.28
    p_rbi_per_pa: float = 0.13
    p_sb_per_onbase: float = 0.035

class CorrelatedRunMC:
    """
    Correlated Negative-Binomial-ish score engine.

    Construction:
    1) shared lognormal game-environment multiplier introduces positive score covariance;
    2) team-specific Gamma-Poisson mixtures preserve overdispersion;
    3) marginal means are rescaled to remain near requested mu values.

    shared_sigma MUST be trained only on exposed historical data.
    """

    def __init__(self, n_sims: int = 25000):
        self.n_sims = int(n_sims)

    @staticmethod
    def _nb_shape(mu: float, vmr: float) -> float:
        # NB variance = mu + mu^2/r ; VMR = 1 + mu/r
        if vmr <= 1:
            return 1e9
        return max(mu / (vmr - 1.0), 1e-6)

    def simulate(self, x: GameRunInputs) -> Dict[str, np.ndarray]:
        rng = np.random.default_rng(x.seed)
        n = self.n_sims

        if min(x.mu_away, x.mu_home) <= 0:
            raise ValueError("Expected runs must be positive.")
        if x.dispersion_vmr < 1:
            raise ValueError("dispersion_vmr must be >= 1.")
        if x.shared_sigma < 0:
            raise ValueError("shared_sigma must be >= 0.")

        if x.shared_sigma > 0:
            # mean-one lognormal factor
            shared = rng.lognormal(
                mean=-0.5*x.shared_sigma*x.shared_sigma,
                sigma=x.shared_sigma,
                size=n
            )
        else:
            shared = np.ones(n)

        def draw_team(mu: float) -> np.ndarray:
            r = self._nb_shape(mu, x.dispersion_vmr)
            # independent gamma multiplier with mean 1
            team_mult = rng.gamma(shape=r, scale=1.0/r, size=n)
            lam = mu * shared * team_mult
            return rng.poisson(lam)

        away = draw_team(x.mu_away)
        home = draw_team(x.mu_home)
        return {
            "away": away,
            "home": home,
            "total": away + home,
            "margin_home": home - away,
        }

    def price_game(self, x: GameRunInputs, total_line: Optional[float]=None) -> Dict[str, float]:
        s = self.simulate(x)
        away, home = s["away"], s["home"]
        margin = s["margin_home"]
        total = s["total"]

        # MLB ties after 9 innings are resolved; research simplification:
        # split tied regulation simulations 50/50 for ML only.
        ties = (home == away)
        home_ml = np.mean(home > away) + 0.5*np.mean(ties)
        away_ml = 1.0 - home_ml

        out = {
            "p_home_ml": float(home_ml),
            "p_away_ml": float(away_ml),
            "p_home_minus_1_5": float(np.mean(margin >= 2)),
            "p_away_plus_1_5": float(np.mean(margin <= 1)),
            "p_away_minus_1_5": float(np.mean(margin <= -2)),
            "p_home_plus_1_5": float(np.mean(margin >= -1)),
            "mean_total": float(np.mean(total)),
            "score_corr": float(np.corrcoef(away, home)[0,1]),
            "margin_sd": float(np.std(margin, ddof=1)),
        }
        if total_line is not None:
            out.update({
                "p_over": float(np.mean(total > total_line)),
                "p_under": float(np.mean(total < total_line)),
                "p_push": float(np.mean(total == total_line)) if float(total_line).is_integer() else 0.0,
                "p_away_tt_over": float("nan"),
                "p_home_tt_over": float("nan"),
            })
        return out

    def team_total_prob(self, x: GameRunInputs, team: str, line: float) -> Dict[str,float]:
        s = self.simulate(x)
        arr = s["home"] if team.lower()=="home" else s["away"]
        return {
            "p_over": float(np.mean(arr > line)),
            "p_under": float(np.mean(arr < line)),
            "p_push": float(np.mean(arr == line)) if float(line).is_integer() else 0.0,
        }


class BivariatePoissonRunMC:
    """
    Shared-component bivariate Poisson research engine.

    Away = A + C
    Home = H + C

    The shared component C cancels out of the score difference, which can compress
    margin variance while preserving positive score covariance. This is a much better
    structural candidate for the observed RL issue than simply multiplying both teams
    by the same noisy game-environment factor.

    shared_mean must be fitted ONLY on exposed historical score data.
    """
    def __init__(self, n_sims: int = 25000):
        self.n_sims = int(n_sims)

    def simulate(self, mu_away: float, mu_home: float, shared_mean: float,
                 seed: int=0) -> Dict[str, np.ndarray]:
        if shared_mean < 0 or shared_mean >= min(mu_away, mu_home):
            raise ValueError("shared_mean must be >=0 and less than both team means.")
        rng = np.random.default_rng(seed)
        c = rng.poisson(shared_mean, self.n_sims)
        a = rng.poisson(mu_away - shared_mean, self.n_sims)
        h = rng.poisson(mu_home - shared_mean, self.n_sims)
        away = a + c
        home = h + c
        return {
            "away": away,
            "home": home,
            "total": away + home,
            "margin_home": home - away,
        }

    def price(self, mu_away: float, mu_home: float, shared_mean: float,
              total_line: Optional[float]=None, seed: int=0) -> Dict[str,float]:
        s = self.simulate(mu_away, mu_home, shared_mean, seed)
        a,h = s["away"],s["home"]
        m,t = s["margin_home"],s["total"]
        ties = h == a
        out = {
            "p_home_ml": float(np.mean(h>a) + 0.5*np.mean(ties)),
            "p_home_minus_1_5": float(np.mean(m>=2)),
            "p_away_minus_1_5": float(np.mean(m<=-2)),
            "score_corr": float(np.corrcoef(a,h)[0,1]),
            "margin_sd": float(np.std(m, ddof=1)),
            "mean_total": float(np.mean(t)),
        }
        if total_line is not None:
            out.update({
                "p_over": float(np.mean(t>total_line)),
                "p_under": float(np.mean(t<total_line)),
                "p_push": float(np.mean(t==total_line)) if float(total_line).is_integer() else 0.0
            })
        return out


class F5ResearchEngine:
    """
    F5 research-only wrapper.

    Unlike a bad 'subtract bullpen' shortcut, it requires explicit F5 expected-run inputs.
    Those inputs should be generated from starter/bulk workload, TTO, top-order offense,
    park/weather and only the bullpen share expected before the sixth inning.
    """
    def __init__(self, n_sims: int = 25000):
        self.mc = CorrelatedRunMC(n_sims)

    def price(self, mu_away_f5: float, mu_home_f5: float, total_line: Optional[float],
              dispersion_vmr: float, shared_sigma: float, seed: int=0) -> Dict[str,float]:
        return self.mc.price_game(GameRunInputs(
            mu_away=mu_away_f5,
            mu_home=mu_home_f5,
            dispersion_vmr=dispersion_vmr,
            shared_sigma=shared_sigma,
            seed=seed
        ), total_line=total_line)

class FirstInningEngine:
    """
    NRFI/YRFI research model.
    Requires explicit first-inning run intensities for each offense.
    Positive shared environment correlation is allowed via a mean-one lognormal multiplier.
    """
    def __init__(self, n_sims: int = 50000):
        self.n_sims = int(n_sims)

    def price(self, lambda_away_1: float, lambda_home_1: float,
              shared_sigma: float=0.0, seed: int=0) -> Dict[str,float]:
        rng = np.random.default_rng(seed)
        n = self.n_sims
        if shared_sigma > 0:
            shared = rng.lognormal(-0.5*shared_sigma**2, shared_sigma, n)
        else:
            shared = np.ones(n)
        a = rng.poisson(lambda_away_1 * shared)
        h = rng.poisson(lambda_home_1 * shared)
        nrfi = np.mean((a+h)==0)
        return {
            "p_nrfi": float(nrfi),
            "p_yrfi": float(1-nrfi),
            "mean_first_inning_runs": float(np.mean(a+h))
        }

class PitcherPropEngine:
    """
    Distributional pitcher-prop research engine.

    Counts are generated at the batter-faced level; outs use a bounded normal approximation
    until a proper starter-survival model is fitted. This is research-only until validated.
    """
    def __init__(self, n_sims: int=50000):
        self.n_sims = int(n_sims)

    def simulate(self, x: PitcherInputs, seed: int=0) -> Dict[str,np.ndarray]:
        rng = np.random.default_rng(seed)
        n = self.n_sims

        # BF uncertainty: overdispersed Poisson via gamma mixing
        cv2 = max(x.overdispersion, 1e-6)
        shape = 1.0/cv2
        mult = rng.gamma(shape, 1.0/shape, n)
        bf = np.maximum(1, rng.poisson(x.batters_faced_mean * mult))

        k = rng.binomial(bf, np.clip(x.k_rate,0,1))
        bb = rng.binomial(np.maximum(0,bf-k), np.clip(x.bb_rate,0,1))
        hits = rng.binomial(np.maximum(0,bf-k-bb), np.clip(x.hit_rate,0,1))
        er = rng.poisson(np.maximum(0, x.er_rate_per_bf * bf))
        outs = np.rint(rng.normal(x.outs_mean, x.outs_sd, n)).astype(int)
        outs = np.clip(outs, 0, 27)

        return {"bf":bf, "k":k, "bb":bb, "hits":hits, "er":er, "outs":outs}

    def over_under(self, x: PitcherInputs, stat: str, line: float, seed: int=0) -> Dict[str,float]:
        s = self.simulate(x, seed)
        arr = s[stat]
        return {
            "p_over": float(np.mean(arr > line)),
            "p_under": float(np.mean(arr < line)),
            "p_push": float(np.mean(arr == line)) if float(line).is_integer() else 0.0
        }

class BatterPropEngine:
    """
    Plate-appearance multinomial research engine.
    Explicitly keeps HR inside hit/TB accounting so correlated player markets are coherent.
    """
    def __init__(self, n_sims: int=50000):
        self.n_sims = int(n_sims)

    def simulate(self, x: BatterInputs, seed: int=0) -> Dict[str,np.ndarray]:
        rng = np.random.default_rng(seed)
        n = self.n_sims
        pa = np.maximum(1, rng.poisson(x.pa_mean, n))

        probs = np.array([x.p_single,x.p_double,x.p_triple,x.p_hr,x.p_bb,x.p_hbp], dtype=float)
        if np.any(probs < 0) or probs.sum() >= 1:
            raise ValueError("Invalid batter event probabilities.")
        p_out = 1.0 - probs.sum()
        probs = np.append(probs, p_out)

        # simulate variable PA counts game-by-game
        hits = np.zeros(n, dtype=int)
        tb = np.zeros(n, dtype=int)
        hr = np.zeros(n, dtype=int)
        runs = np.zeros(n, dtype=int)
        rbi = np.zeros(n, dtype=int)
        sb = np.zeros(n, dtype=int)

        for i in range(n):
            c = rng.multinomial(int(pa[i]), probs)
            s1,d2,t3,h4,bb,hbp,out = c
            h = s1+d2+t3+h4
            hits[i] = h
            tb[i] = s1+2*d2+3*t3+4*h4
            hr[i] = h4
            onbase = h+bb+hbp
            runs[i] = rng.binomial(onbase, np.clip(x.p_run_given_onbase,0,1))
            rbi[i] = rng.binomial(int(pa[i]), np.clip(x.p_rbi_per_pa,0,1))
            sb[i] = rng.binomial(onbase, np.clip(x.p_sb_per_onbase,0,1))

        return {"pa":pa,"hits":hits,"tb":tb,"hr":hr,"runs":runs,"rbi":rbi,"sb":sb}

    def over_under(self, x: BatterInputs, stat: str, line: float, seed: int=0) -> Dict[str,float]:
        arr = self.simulate(x, seed)[stat]
        return {
            "p_over": float(np.mean(arr > line)),
            "p_under": float(np.mean(arr < line)),
            "p_push": float(np.mean(arr == line)) if float(line).is_integer() else 0.0
        }

def calibration_table(y: np.ndarray, p: np.ndarray, bins: int=10) -> List[dict]:
    y = np.asarray(y, dtype=float)
    p = np.asarray(p, dtype=float)
    edges = np.linspace(0,1,bins+1)
    out=[]
    for i in range(bins):
        lo, hi = edges[i], edges[i+1]
        mask = (p >= lo) & ((p < hi) if i < bins-1 else (p <= hi))
        if mask.sum():
            out.append({
                "lo":float(lo), "hi":float(hi), "n":int(mask.sum()),
                "mean_p":float(p[mask].mean()),
                "actual":float(y[mask].mean())
            })
    return out

MARKET_PROMOTION_GATES = {
    "RL": "Requires fresh historical score-margin holdout and direct calibration of margin distribution.",
    "TEAM_TOTAL": "Requires per-team marginal run calibration on fresh holdout.",
    "F5": "Requires inning-level F5 outcomes + F5 prices; existing v1.9.1 engineering gate remains research-only.",
    "NRFI_YRFI": "Requires first-inning outcomes/prices, confirmed lineup sensitivity tests, Brier/log-loss calibration.",
    "PITCHER_PROPS": "Requires point-in-time BF/workload and market-specific outcomes/prices, walk-forward calibration.",
    "HITTER_PROPS": "Requires PA/lineup-slot point-in-time features and player-market walk-forward validation.",
    "HR": "Requires HR-specific calibration with larger uncertainty buffer due sparse-event variance.",
}


# ============================================================
# SportsEdge Multi-Market Engine v1 — structural rebuild layer
# Added 2026-08-09
# ============================================================

@dataclass
class PitcherBBParams:
    """
    Dedicated BB model.
    Key design choice: NO generic per-game rate-noise term.
    The prior failure over-dispersed a low-rate count and created too many 0-BB starts.
    """
    bf_mean: float
    bb_rate: float
    # Starter BF is empirically tighter than Poisson once expected workload is known.
    # Use a train/dev-fitted residual SD; do NOT force gamma-Poisson overdispersion.
    bf_sd: float = 4.0
    bf_min: int = 1
    bf_max: int = 40

class PitcherBBEngine:
    def __init__(self, n_sims: int = 50000):
        self.n_sims = int(n_sims)

    def simulate(self, x: PitcherBBParams, seed: int = 0) -> np.ndarray:
        rng = np.random.default_rng(seed)
        bf = np.rint(rng.normal(float(x.bf_mean), max(float(x.bf_sd), 0.25), self.n_sims)).astype(int)
        bf = np.clip(bf, int(x.bf_min), int(x.bf_max))
        # Crucial: fixed matchup-adjusted BB probability within a start.
        # No generic per-start BB-rate noise.
        return rng.binomial(bf, np.clip(float(x.bb_rate), 0.0, 1.0))

    def price(self, x: PitcherBBParams, line: float, seed: int = 0) -> Dict[str, float]:
        arr = self.simulate(x, seed)
        return empirical_ou(arr, line)


@dataclass
class PitcherERMixtureParams:
    """
    Robust two-state ER model:
    normal state + blow-up state.

    The mixture parameters MUST be estimated on training data only.
    This avoids forcing one Poisson/NB dispersion parameter to explain both
    ordinary starts and a small catastrophic tail.
    """
    bf_mean: float
    normal_er_per_bf: float
    blowup_er_per_bf: float
    blowup_prob: float
    # Keep workload uncertainty separate from ER-state dispersion.
    bf_sd: float = 4.0
    bf_min: int = 1
    bf_max: int = 40
    normal_vmr: float = 1.25
    blowup_vmr: float = 1.60

class PitcherERMixtureEngine:
    def __init__(self, n_sims: int = 50000):
        self.n_sims = int(n_sims)

    @staticmethod
    def _gamma_poisson(rng, mu, vmr):
        mu = np.asarray(mu, dtype=float)
        vmr = max(float(vmr), 1.0)
        if vmr <= 1.000001:
            return rng.poisson(mu)
        shape = np.maximum(mu / max(vmr - 1.0, 1e-8), 1e-4)
        lam = rng.gamma(shape=shape, scale=np.divide(mu, shape, out=np.ones_like(mu), where=shape>0))
        return rng.poisson(lam)

    def simulate(self, x: PitcherERMixtureParams, seed: int = 0) -> np.ndarray:
        rng = np.random.default_rng(seed)
        bf = np.rint(rng.normal(float(x.bf_mean), max(float(x.bf_sd), 0.25), self.n_sims)).astype(int)
        bf = np.clip(bf, int(x.bf_min), int(x.bf_max))
        is_blow = rng.random(self.n_sims) < np.clip(float(x.blowup_prob), 0, 1)

        mu_normal = bf * max(float(x.normal_er_per_bf), 0.0)
        mu_blow = bf * max(float(x.blowup_er_per_bf), 0.0)
        normal = self._gamma_poisson(rng, mu_normal, x.normal_vmr)
        blow = self._gamma_poisson(rng, mu_blow, x.blowup_vmr)
        return np.where(is_blow, blow, normal)

    def price(self, x: PitcherERMixtureParams, line: float, seed: int = 0) -> Dict[str, float]:
        return empirical_ou(self.simulate(x, seed), line)


@dataclass
class SharedTeamEffect:
    """
    Shared latent game/team state.
    sigma=0 means no shared effect.
    Positive sigma creates more lineup-wide collar and eruption games; sigma must earn its place OOS.
    Fit sigma on training only.
    """
    sigma: float = 0.0

def _logit(p):
    p = np.clip(np.asarray(p, dtype=float), 1e-8, 1-1e-8)
    return np.log(p/(1-p))

def _expit(z):
    return 1.0/(1.0+np.exp(-np.asarray(z, dtype=float)))

def apply_shared_logit_factor(base_p: np.ndarray, z: float) -> np.ndarray:
    return _expit(_logit(base_p) + float(z))


@dataclass
class JointBatter:
    name: str
    pa_mean: float
    p_single: float
    p_double: float
    p_triple: float
    p_hr: float
    p_bb: float
    p_hbp: float = 0.0
    p_sb_attempt_given_1b: float = 0.03
    p_sb_success: float = 0.75

class JointLineupMC:
    """
    Joint 9-hitter simulation with a shared team/game latent effect.
    Outputs hitter hits/TB/HR/RBI/runs/SB from the SAME paths,
    allowing SGP probabilities to be empirical rather than independence products.

    This is a compact production-oriented base-state model, not a play-by-play simulator.
    It preserves:
      - correlated team-wide good/bad offensive states
      - lineup order
      - RBI/run dependence through baserunner state
      - SB dependence on singles/walks/HBP and success probability
    """
    def __init__(self, n_sims: int = 25000):
        self.n_sims = int(n_sims)

    def simulate_team(
        self,
        lineup: List[JointBatter],
        shared_effect: SharedTeamEffect,
        team_pa_mean: float = 38.0,
        team_pa_sd: float = 4.7,
        seed: int = 0
    ) -> Dict[str, np.ndarray]:
        if not lineup:
            raise ValueError("lineup is empty")
        if len(lineup) > 9:
            raise ValueError("lineup must have <= 9 hitters")

        rng = np.random.default_rng(seed)
        n = self.n_sims
        m = len(lineup)

        hits = np.zeros((n,m), dtype=int)
        tb = np.zeros((n,m), dtype=int)
        hr = np.zeros((n,m), dtype=int)
        runs = np.zeros((n,m), dtype=int)
        rbi = np.zeros((n,m), dtype=int)
        sb = np.zeros((n,m), dtype=int)
        pa = np.zeros((n,m), dtype=int)

        # Team-wide latent state for each simulation.
        z_team = rng.normal(0.0, max(float(shared_effect.sigma), 0.0), n)

        # Plate appearances are NOT multinomial across lineup slots. A batting order
        # cycles: every completed turn gives each slot one PA, then the next r slots
        # receive one additional PA. The old multinomial allocator materially
        # overstated player-level PA variance and created artificial 0-hit/3+ hit tails.
        for s in range(n):
            total_pa = int(np.rint(rng.normal(max(team_pa_mean, float(m)), max(team_pa_sd, 0.5))))
            total_pa = max(m, total_pa)
            q, r = divmod(total_pa, m)
            pa_s = np.full(m, q, dtype=int)
            if r:
                pa_s[:r] += 1
            pa[s] = pa_s

            # Simple base state: runner owner indices on 1B/2B/3B.
            bases = [None, None, None]
            outs_in_inning = 0

            # Process the actual batting-order sequence. The prior v1 loop processed
            # all PAs for slot 1, then all PAs for slot 2, etc., which invalidated
            # base-state/RBI/run dependence and any downstream SGP correlation.
            sequence = list(range(m)) * q + list(range(r))
            for slot in sequence:
                batter = lineup[slot]
                raw = np.array([
                    batter.p_single, batter.p_double, batter.p_triple,
                    batter.p_hr, batter.p_bb, batter.p_hbp
                ], dtype=float)

                hit_mass = raw[:4].sum()
                reach_mass = raw.sum()

                # Shared factor moves all positive-event odds together.
                # Preserve relative event mix within hit/reach categories.
                hit_prob = float(apply_shared_logit_factor(np.array([hit_mass]), z_team[s])[0])
                nonhit_reach = max(reach_mass-hit_mass, 0.0)
                nonhit_reach_prob = float(
                    apply_shared_logit_factor(np.array([nonhit_reach]), 0.45*z_team[s])[0]
                )

                hmix = raw[:4] / hit_mass if hit_mass > 0 else np.array([1,0,0,0], dtype=float)
                reach_mix = raw[4:6] / nonhit_reach if nonhit_reach > 0 else np.array([1,0], dtype=float)

                p1,p2,p3,phr = hit_prob * hmix
                pbb,phbp = nonhit_reach_prob * reach_mix
                probs = np.array([p1,p2,p3,phr,pbb,phbp], dtype=float)
                if probs.sum() >= 0.98:
                    probs *= 0.98/probs.sum()
                probs = np.append(probs, 1-probs.sum())

                outcome = rng.choice(7, p=probs)
                if outcome == 6:
                    outs_in_inning += 1
                    if outs_in_inning >= 3:
                        outs_in_inning = 0
                        bases = [None, None, None]
                    continue

                if outcome == 3:  # HR
                    hr[s,slot] += 1
                    hits[s,slot] += 1
                    tb[s,slot] += 4
                    # batter + all occupied runners score
                    scored = [idx for idx in bases if idx is not None]
                    for idx in scored:
                        runs[s,idx] += 1
                    runs[s,slot] += 1
                    rbi[s,slot] += 1 + len(scored)
                    bases = [None,None,None]
                    continue

                if outcome in (0,1,2):  # single/double/triple
                    hits[s,slot] += 1
                    base_count = outcome + 1
                    tb[s,slot] += base_count

                    old = bases[:]
                    bases = [None,None,None]
                    for bidx in range(2,-1,-1):
                        runner = old[bidx]
                        if runner is None:
                            continue
                        new_base = bidx + base_count
                        if new_base >= 3:
                            runs[s,runner] += 1
                            rbi[s,slot] += 1
                        else:
                            bases[new_base] = runner

                    if base_count >= 3:
                        bases[2] = slot
                    else:
                        bases[base_count-1] = slot

                    # SB only after a single, using a dedicated attempt/success process.
                    if base_count == 1 and rng.random() < batter.p_sb_attempt_given_1b:
                        if rng.random() < batter.p_sb_success and bases[1] is None:
                            bases[1] = bases[0]
                            bases[0] = None
                            sb[s,slot] += 1
                    continue

                # BB/HBP: forced one-base advancement.
                old1, old2, old3 = bases
                if old1 is not None and old2 is not None and old3 is not None:
                    runs[s,old3] += 1
                    rbi[s,slot] += 1
                if old2 is not None and old1 is not None:
                    bases[2] = old2
                if old1 is not None:
                    bases[1] = old1
                bases[0] = slot

        return {
            "pa":pa, "hits":hits, "tb":tb, "hr":hr,
            "runs":runs, "rbi":rbi, "sb":sb,
            "team_runs":runs.sum(axis=1)
        }


def empirical_ou(arr: np.ndarray, line: float) -> Dict[str, float]:
    arr = np.asarray(arr)
    return {
        "p_over": float(np.mean(arr > line)),
        "p_under": float(np.mean(arr < line)),
        "p_push": float(np.mean(arr == line)) if float(line).is_integer() else 0.0,
        "mean": float(np.mean(arr)),
        "variance": float(np.var(arr, ddof=1)) if arr.size > 1 else 0.0,
    }


@dataclass
class SGPLeg:
    key: str
    values: np.ndarray
    threshold: float
    direction: str = "over"

    def mask(self) -> np.ndarray:
        x = np.asarray(self.values)
        d = self.direction.lower()
        if d == "over":
            return x > self.threshold
        if d == "under":
            return x < self.threshold
        if d == "yes":
            return x.astype(bool)
        if d == "no":
            return ~x.astype(bool)
        raise ValueError("direction must be over/under/yes/no")

class SGPEngine:
    """
    Prices SGPs directly from shared simulation paths.
    Never multiplies independent probabilities to produce the official joint price.
    """
    @staticmethod
    def price(legs: List[SGPLeg]) -> Dict[str, float]:
        if len(legs) < 2:
            raise ValueError("Need at least two legs")
        masks = [leg.mask() for leg in legs]
        n = len(masks[0])
        if any(len(m) != n for m in masks):
            raise ValueError("All legs must come from the same simulation paths")

        joint = np.logical_and.reduce(masks)
        marginals = np.array([m.mean() for m in masks], dtype=float)
        naive = float(np.prod(marginals))
        p_joint = float(joint.mean())

        # Pairwise phi-style correlations for audit.
        corr = {}
        for i in range(len(masks)):
            for j in range(i+1, len(masks)):
                a, b = masks[i].astype(float), masks[j].astype(float)
                if a.std() == 0 or b.std() == 0:
                    c = 0.0
                else:
                    c = float(np.corrcoef(a,b)[0,1])
                corr[f"{legs[i].key}|{legs[j].key}"] = c

        return {
            "p_joint": p_joint,
            "naive_independence_p": naive,
            "dependence_ratio": p_joint / naive if naive > 0 else float("nan"),
            "fair_american": prob_to_american(p_joint),
            "pairwise_corr": corr,
        }


def validation_summary(y: np.ndarray, p: np.ndarray) -> Dict[str, float]:
    y = np.asarray(y, dtype=float)
    p = np.clip(np.asarray(p, dtype=float), EPS, 1-EPS)
    n = len(y)
    gap = float(p.mean() - y.mean())
    se = float(np.sqrt(max(y.mean()*(1-y.mean()), 1e-9) / max(n,1)))
    return {
        "n": int(n),
        "pred_mean": float(p.mean()),
        "actual_mean": float(y.mean()),
        "gap_pp": 100.0*gap,
        "gap_se": abs(gap)/se if se > 0 else float("nan"),
        "brier": brier(y,p),
        "logloss": logloss(y,p),
    }


PASS_RULES_V1 = {
    "PITCHER_BB": {
        "required": "Train-only fit; OOS common lines; no systematic low-tail miss; mean/variance stable."
    },
    "PITCHER_ER": {
        "required": "Train-only robust mixture fit; OOS 1.5/2.5/3.5/4.5; catastrophe tail calibration."
    },
    "HITTER_HITS_TB": {
        "required": "Shared game/team effect fit on training only; OOS 0.5/1.5/2.5; mean preserved."
    },
    "RBI_RUNS": {
        "required": "Joint lineup/base-state model; OOS 0.5 calibration by lineup bucket and run environment."
    },
    "SB": {
        "required": "OOS 0.5; on-base × attempt × success; pitcher/catcher context when available."
    },
    "SGP": {
        "required": "All component markets validated; same-path joint simulation; calibration on offered combinations."
    },
}

# ============================================================
# v1.2 — walk-forward calibration + validation gates
# Added 2026-08-09
# ============================================================

@dataclass
class WalkForwardCalibrationState:
    """Production-safe online residual calibration state.

    Update only after an event/date has completed. Predictions for a date are made
    from prior-date residuals, never same-day/future outcomes. This is how the model
    adapts to season-level run/hit/walk environment shifts without contaminating OOS
    validation.
    """
    prior_strength: float
    cumulative_actual: float = 0.0
    cumulative_predicted: float = 0.0
    cumulative_n: int = 0

    def delta_logit(self) -> float:
        s = max(float(self.prior_strength), 0.0)
        den = self.cumulative_n + s
        if den <= 0:
            return 0.0
        a = (self.cumulative_actual + 0.5*s) / den
        p = (self.cumulative_predicted + 0.5*s) / den
        a = float(np.clip(a, 1e-5, 1-1e-5))
        p = float(np.clip(p, 1e-5, 1-1e-5))
        return float(_logit(a) - _logit(p))

    def calibrate(self, base_probability: float) -> float:
        p = float(np.clip(base_probability, 1e-6, 1-1e-6))
        return float(_expit(_logit(p) + self.delta_logit()))

    def update_completed_batch(self, predicted: np.ndarray, actual: np.ndarray) -> None:
        p = np.asarray(predicted, dtype=float)
        y = np.asarray(actual, dtype=float)
        if p.shape != y.shape:
            raise ValueError("predicted and actual must have the same shape")
        self.cumulative_predicted += float(np.sum(p))
        self.cumulative_actual += float(np.sum(y))
        self.cumulative_n += int(y.size)


# Nested-temporal strengths selected without reading 2024 outcomes:
# 2021 fit -> 2022 static calibration -> 2023 prequential strength tuning.
ONLINE_CALIBRATION_STRENGTHS_V1 = {
    ("PITCHER_BB", 1.5): 225.0,
    ("PITCHER_BB", 2.5): 500.0,
    ("PITCHER_BB", 3.5): 75.0,
    ("HITTER_HITS", 1.5): 100.0,
    ("HITTER_TB", 2.5): 100.0,
    # defaults used for lines not requiring line-specific adaptation
    ("PITCHER_DEFAULT", None): 350.0,
    ("HITTER_DEFAULT", None): 1800.0,
}


def validation_gate(gap_se: float) -> str:
    """Project-consistent calibration gate.

    PASS <= 2 SE.
    PASS_CAUTION >2 and <=2.5 SE, matching prior SportsEdge treatment of
    validated K/HR tail bands around ~2.1-2.45 SE.
    FAIL >2.5 SE.
    """
    x = abs(float(gap_se))
    if x <= 2.0:
        return "PASS"
    if x <= 2.5:
        return "PASS_CAUTION"
    return "FAIL"


VALIDATION_STATE_V1_2 = {
    "PITCHER_BB": "PASS_CAUTION",
    "PITCHER_ER": "PASS",
    "HITTER_HITS": "PASS",
    "HITTER_TB": "PASS",
    "HITTER_RBI": "PASS",
    "HITTER_RUNS": "PASS",
    "HITTER_SB": "PASS",
    "SGP_DEPENDENCE": "PASS",
}

import json, sys, tempfile
from pathlib import Path
from datetime import datetime, timezone, timedelta
import importlib.util

BASE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('runner_v11',BASE/'sportsedge_runner_v1_1.py')
runner=importlib.util.module_from_spec(spec); sys.modules['runner_v11']=runner; spec.loader.exec_module(runner)

now=datetime.now(timezone.utc)
def ts(sec=0): return (now-timedelta(seconds=sec)).isoformat()

cfg=json.loads((BASE/'test_fixture_hou_sd.json').read_text())
cfg['game_sims']=1000; cfg['search_sims']=500; cfg['hitter_sims']=1000; cfg['pitcher_sims']=1000
cfg['markets']=[r for r in cfg['markets'] if r['market'] in ('moneyline','hr')][:3]

sources=['dk_prices','schedule','starters','lineups','scratches','weather','roof','umpire','bullpen','statcast','park']
snap={
 'game_id':'TEST','game_time':'2099-01-01T00:00:00Z',
 'sources':{s:{'available':True,'as_of':ts(10),'provider':'fixture'} for s in sources},
 'game_state':{'starter_status':'CONFIRMED','lineup_status':'CONFIRMED','weather_status':'OK'},
 'model_config':cfg, 'markets':cfg['markets'],
 'required_market_families':['moneyline','hr','pitcher earned runs']
}

# Registry must fail closed on blocked ER while other families remain present.
out=runner.run_snapshot(snap,BASE)
assert any(x['market']=='pitcher earned runs' and x['status']=='BLOCKED' for x in out['market_audit'])
assert {x['market'] for x in out['market_audit']} == {'moneyline','hr','pitcher earned runs'}

# Missing DK price: distinguish MISSING_PRICE and still request screenshot.
s2=json.loads(json.dumps(snap)); s2['sources']['dk_prices']={'available':False,'as_of':None,'provider':'fixture'}
o2=runner.run_snapshot(s2,BASE)
assert any(x['market']=='moneyline' and x['status']=='MISSING_PRICE' for x in o2['market_audit'])
assert o2['screenshot_requests']

# Stale DK price: distinguish STALE_PRICE and still request screenshot.
s3=json.loads(json.dumps(snap)); s3['sources']['dk_prices']['as_of']=ts(9999)
o3=runner.run_snapshot(s3,BASE)
assert any(x['market']=='moneyline' and x['status']=='STALE_PRICE' for x in o3['market_audit'])
assert o3['screenshot_requests']

# Unknown DK timestamp: separate status and screenshot remedy.
s4=json.loads(json.dumps(snap)); s4['sources']['dk_prices']['as_of']=None
o4=runner.run_snapshot(s4,BASE)
assert any(x['market']=='moneyline' and x['status']=='UNKNOWN_PRICE_FRESHNESS' for x in o4['market_audit'])
assert o4['screenshot_requests']

# Multiple simultaneous problems must all survive audit; screenshot hint cannot be lost.
s5=json.loads(json.dumps(snap)); s5['sources']['dk_prices']['as_of']=ts(9999); s5['sources']['weather']['as_of']=ts(30000)
o5=runner.run_snapshot(s5,BASE)
hr=next(x for x in o5['market_audit'] if x['market']=='hr')
assert 'dk_prices' in hr['stale_sources'] and 'weather' in hr['stale_sources']
assert any(r['action']=='SCREENSHOT_REQUIRED' for r in hr['remediation'])
assert o5['screenshot_requests']

# Unknown freshness on non-price source remains distinct and does not invent freshness.
s6=json.loads(json.dumps(snap)); s6['sources']['statcast']['as_of']=None
o6=runner.run_snapshot(s6,BASE)
assert any(x['market']=='hr' and x['status']=='UNKNOWN_FRESHNESS' for x in o6['market_audit'])


# Registry measured-state/parity assertions.
engine=runner.load_module(BASE/'sportsedge_beta_v1_4.py','sportsedge_beta_v1_4_registry_test')
assert engine.validation_record('hits')['status']=='PASS_CAUTION' and engine.validation_record('hits')['official_eligible']
assert engine.validation_record('total bases')['status']=='PASS' and engine.validation_record('total bases')['official_eligible']
assert engine.validation_record('pitcher walks')['status']=='PASS_CAUTION' and engine.validation_record('pitcher walks')['official_eligible']
assert engine.validation_record('sgp')['status']=='PASS_GATED' and engine.validation_record('sgp')['official_eligible']
assert not engine.validation_record('pitcher earned runs')['official_eligible']
assert engine.validation_record('rbi')['status']=='VALIDATED_NOT_DEPLOYED' and not engine.validation_record('rbi')['official_eligible']
assert engine.validation_record('runs')['status']=='VALIDATED_NOT_DEPLOYED' and not engine.validation_record('runs')['official_eligible']
assert engine.validation_record('sb')['status']=='BLOCKED_UNBUILT' and not engine.validation_record('sb')['official_eligible']

print('ALL RUNNER V1.1.1 TESTS PASS')
